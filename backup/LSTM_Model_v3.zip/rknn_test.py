import os
import numpy as np
from rknn.api import RKNN

# 设置rknn模型和测试数据文件夹的路径
RKNN_MODEL = './model/lstm.rknn'
DATA_PATH = './data/test'

# 设置输入参数
files = os.listdir(DATA_PATH)   # 读入文件夹
num_files = len(files)          # 统计文件夹中的文件个数
print('文件个数：',num_files)

input_expand = 1           # 与输入保持一致，扩展一个维度
input_high = 1              # 由于测试数据为一维，所以将数据的另一个维度设置为1
input_width = 2           # 输入数据的维度

# 初始化变量
input_data = np.zeros((num_files, input_expand, input_high, input_width), dtype=np.float32)    # 创建输入张量
true_data = np.zeros((num_files, input_expand), dtype=np.float32)    # 创建输入张量
ans = np.zeros((num_files, input_expand, input_high), dtype=np.float32)   # 创建推理结果张量
mean_error = np.arange(num_files, dtype=np.float32)   # 创建推理结果张量

# 导入推理测试数据
for i in range(0, num_files):
    input_data[i] = np.load('./data/test/test%d.npy'%i)  # 将预处理后的数据设置为输入张量的数据
    true_data[i] = np.load('./data/true/true%d.npy'%i)  # 将预处理后的数据设置为输入张量的数据

# 加速推理的主程序
if __name__ == '__main__':

    # Create RKNN object
    rknn = RKNN()

    # Load model
    print('--> Loading model')
    ret = rknn.load_rknn(path=RKNN_MODEL)
    if ret != 0:
        print('Load model failed!')
        exit(ret)
    print('done')

    # Init runtime environment
    print('--> Init runtime environment')
    ret = rknn.init_runtime(
        target='rk3568',
        device_id='559a70eae2390ef9'
    )
    
    if ret != 0:
        print('Init runtime environment failed!')
        exit(ret)
    print('done')

    # Inference
    print('--> Running model')
    for i in range(0, num_files):
        outputs = rknn.inference(inputs=[input_data[i]])
        ans[i, :] =  np.array(outputs)
    np.savetxt('output.csv', ans[:,:,0], delimiter=',')

    for i in range(0, num_files):
        mean_error[i] = abs((ans[i, 0] - true_data[i, 0])) / true_data[i, 0]
        if true_data[i, 0] == 0:
            print(i)

    has_inf = np.isinf(mean_error)
    if np.any(has_inf):
        print("存在无穷大的元素，剔除计算剩余元素")# 使用布尔索引选择非无穷大的元素
        print(has_inf)
        valid_error = mean_error[~has_inf]

        # 计算剩余元素的和
        error_sum = np.sum(valid_error)
        mean_error = error_sum / (len(valid_error))
    else:
        error_sum = np.sum(mean_error)
        mean_error = error_sum / (len(mean_error))

    print("平均误差为：", mean_error)

    rknn.release()
