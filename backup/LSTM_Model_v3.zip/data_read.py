import numpy as np
import csv
import os

# 设置rknn模型和测试数据文件夹的路径
ONNX_MODEL = './model/lstm.onnx'
QUANT_DATA = './dataset.txt'
RKNN_MODEL = './model/lstm.rknn'
DATA_PATH = './data/test'
TRUE_PATH = './data/true/true.npy'

# 设置输入参数
files = os.listdir(DATA_PATH)   # 读入文件夹
num_files = len(files)          # 统计文件夹中的文件个数(获取测试集的数量)
print('文件数量为：', num_files)
batch_size = 50             # 批量大小
input_expand = 100          # 与输入保持一致，扩展一个维度
input_high = 1              # 由于测试数据为一维，所以将数据的另一个维度设置为1
input_width = 2             # 输入数据的维度

# 初始化变量
input_data = np.zeros((batch_size, input_expand, input_high, input_width), dtype=np.float32)    # 创建输入张量
true_data = np.zeros((batch_size, input_expand, input_high), dtype=np.float32)    # 创建输入张量
ans = np.zeros((num_files, input_expand, input_high), dtype=np.float32)   # 创建推理结果张量
mean_error = np.arange(num_files*input_expand, dtype=np.float32)   # 创建推理结果张量

filename='./data/test.csv'
count = 0
with open (filename,'r') as f:
    csv_reader = csv.reader(f)
    for row in csv_reader:
        count +=1
print('The total lines is ',count)


# for i in range(0, num_files):
#     input_data[i] = np.load('./data/test/test%d.npy'%i)  # 将预处理后的数据设置为输入张量的数据


# np.savetxt('/home/shade/rk3568/python/electric_model/data/test.txt', input_data)
