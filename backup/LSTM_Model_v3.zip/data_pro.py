import numpy as np
import pandas as pd
import torch
import os
from sklearn.preprocessing import MinMaxScaler

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/raw_data.xlsx", sheet_name="#18-2",engine='openpyxl')

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']

dataX = data_df[selected_features].values

# 归一化数据
scaler = MinMaxScaler()
data_normalized1 = scaler.fit_transform(dataX)

# 转换为 PyTorch 张量
X_test = torch.tensor(data_normalized1, dtype=torch.float32)
X_test = X_test.unsqueeze(1)

def delete_files(directory):
    file_list = os.listdir(directory)
    for file in file_list:
        file_path = os.path.join(directory, file)
        if os.path.isfile(file_path):
            os.remove(file_path)

DATASET_PATH = './dataset.txt'
QUANT_PATH = './data/quant'
os.remove(DATASET_PATH)
delete_files(QUANT_PATH)

file = open(DATASET_PATH, 'a')

# 提取出50组用于量化的数据
for j in range(0, 50):
    np.save(file="./data/quant/test%d.npy"%j, arr=X_test[j, :])
    file.write("./data/quant/test%d.npy\n"%j)

