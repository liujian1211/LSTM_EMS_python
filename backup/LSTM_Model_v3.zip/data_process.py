import numpy as np
import pandas as pd
import torch
import os
from sklearn.preprocessing import MinMaxScaler

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/raw_data.xlsx", sheet_name="#18-2",engine='openpyxl')

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']
target_column = 'Qdc'

dataX = data_df[selected_features].values
datay = data_df[[target_column]].values
print('dataX = ', dataX)
print('datay = ', datay)

# 归一化数据
scaler = MinMaxScaler()
data_normalized1 = scaler.fit_transform(dataX)
Y_test = scaler.fit_transform(datay)

# 划分训练集和测试集
X_test = torch.tensor(data_normalized1, dtype=torch.float32)
X_test = X_test.unsqueeze(1)

def delete_files(directory):
    file_list = os.listdir(directory)
    for file in file_list:
        file_path = os.path.join(directory, file)
        if os.path.isfile(file_path):
            os.remove(file_path)

DATASET_PATH = '/home/shade/rk3568/python/electric_model/dataset.txt'
TEST_PATH = '/home/shade/rk3568/python/electric_model/data/test'
QUANT_PATH = '/home/shade/rk3568/python/electric_model/data/quant'
TRUE_PATH = '/home/shade/rk3568/python/electric_model/data/true'
os.remove(DATASET_PATH)
delete_files(TEST_PATH)
delete_files(QUANT_PATH)
delete_files(TRUE_PATH)

#文件数量
length = (int)(len(datay) / 100)
print("data size = ", length)

file = open(DATASET_PATH, 'a')

# 提取出50组用于量化的数据
for j in range(0, 50):
    np.save(file="/home/shade/rk3568/python/electric_model/data/quant/test%d.npy"%j, arr=X_test[j*100:((j+1)*100), :])
    file.write("./data/test/test%d.npy\n"%j)

# 将剩余数据输出，作为测试数据
for j in range(50, length):
    np.save(file="/home/shade/rk3568/python/electric_model/data/test/test%d.npy"%(j - 50), arr=X_test[j*100:((j+1)*100), :])
    np.save(file="/home/shade/rk3568/python/electric_model/data/true/true%d.npy"%(j - 50), arr=Y_test[j*100:((j+1)*100)])
