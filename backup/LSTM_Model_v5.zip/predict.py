import numpy as np
import pandas as pd
import onnx
import torch
import torch.onnx
import torch.nn as nn
from torch.onnx import utils
from sklearn.preprocessing import MinMaxScaler
import onnxruntime as ort

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/test_data.xlsx", sheet_name="#18-2",engine='openpyxl')
num_files = data_df.shape[0]

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']
target_column = 'Qdc'
# data = data_df[selected_features + [target_column]].values
dataX = data_df[selected_features].values
datay = data_df[[target_column]].values
# time_data = pd.to_datetime(data_df[["Year", "Month", "Day", "Hour"]])  # 时间列（合并）
time_data = pd.to_datetime(data_df['日期'].astype(str) + ' ' + data_df['时间'].astype(str))
# print(type(time_data))
# print(time_data)
data_time = time_data.values
data_time = data_time.astype(str)

# 归一化数据
scaler1 = MinMaxScaler()
data_normalized1 = scaler1.fit_transform(dataX)

scaler2 = MinMaxScaler()
data_normalized2 = scaler2.fit_transform(datay)

# 划分特征和目标变量
X = data_normalized1[:, :]  # 特征
y = data_normalized2[:, -1]  # 目标变量
# 组合特征与时间
X = np.concatenate((X, data_time.reshape(-1, 1)), axis=1)

# 划分训练集和测试集
X_test_ini = X
y_test = y

X_test = X_test_ini[:, :2]
X_test = X_test.astype(np.float64)
X_test_time = X_test_ini[:, 2]
# print(X_test_time)
torch.manual_seed(42)  # 保证每次跑的结果相同
# 转换为 PyTorch 张量

X_test = torch.tensor(X_test, dtype=torch.float32)
X_test = X_test.unsqueeze(1)
X_test = X_test.unsqueeze(1)

# 加载ONNX模型
sess = ort.InferenceSession("./model/lstm_model.onnx")

# 获取输入和输出名称
input_name = sess.get_inputs()[0].name
output_name = sess.get_outputs()[0].name

result = np.zeros((num_files, 1), dtype=np.float32)   # 创建推理结果张量
mean_error = np.arange(num_files, dtype=np.float32)   # 创建推理结果张量

# 运行ONNX模型
for i in range(0, num_files):
    result[i] = np.array(sess.run([output_name], {input_name: X_test[i].numpy()}))
result = scaler2.inverse_transform(result)
np.savetxt('./output/predict.csv', result, delimiter=',')

for i in range(0, num_files):
        mean_error[i] = abs((result[i] - datay[i])) / datay[i]
error_sum = np.sum(mean_error)
mean_error = error_sum / (len(mean_error))
print("The Mean Error = ", mean_error)