import numpy as np
from rknn.api import RKNN
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 设置rknn模型和测试数据文件夹的路径
RKNN_MODEL = './model/lstm.rknn'

input_expand = 1            # 与输入保持一致，扩展一个维度
input_high = 1              # 由于测试数据为一维，所以将数据的另一个维度设置为1
input_width = 2           # 输入数据的维度

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/test_data.xlsx", sheet_name="#18-2",engine='openpyxl')
predict = np.loadtxt('./output/predict.csv', delimiter=',', skiprows=0, dtype=np.float32)

num_files = data_df.shape[0]

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']
target_column = 'Qdc'

dataX = data_df[selected_features].values
datay = data_df[[target_column]].values
# print("datay = ", datay)

# 归一化数据
scaler1 = MinMaxScaler()
data_normalized1 = scaler1.fit_transform(dataX)

scaler2 = MinMaxScaler()
data_normalized2 = scaler2.fit_transform(datay)

# 导入推理测试数据
input_data = data_normalized1.reshape((num_files, input_expand, input_high, input_width))
input_data = input_data.astype(np.float32)

np.savetxt('./output/input.csv', input_data.reshape((num_files, input_width)), delimiter=',')
# print('true_data = ',input_data.shape)
np.savetxt('./output/output_raw.csv', datay, delimiter=',')
# print('output_size = ',y_test.shape)

# 初始化变量
ans = np.zeros((num_files, input_expand), dtype=np.float32)   # 创建推理结果张量
mean_error1 = np.arange(num_files*input_expand, dtype=np.float32)   # 创建推理结果张量
mean_error2 = np.arange(num_files*input_expand, dtype=np.float32)   # 创建推理结果张量

# 加速推理的主程序
if __name__ == '__main__':

    # Create RKNN object
    rknn = RKNN()

    # Load model
    print('--> Loading model')
    ret = rknn.load_rknn(path=RKNN_MODEL)
    if ret != 0:
        print('Load model failed!')
        exit(ret)
    print('done')

    # Init runtime environment
    print('--> Init runtime environment')
    ret = rknn.init_runtime(
        target='rk3568',
        device_id='559a70eae2390ef9'
    )
    
    if ret != 0:
        print('Init runtime environment failed!')
        exit(ret)
    print('done')

    # Inference
    print('--> Running model')
    for i in range(0, num_files):
        ans[i] = rknn.inference(inputs=[input_data[i]])
        # print("input_data = ", input_data[i])
        # print("predict = ", outputs)
        # print("true_data = ", predict[i])
    ans = scaler2.inverse_transform(ans)

    # print("input_size = ", input_data[i].shape)
    # print("ans_size = ",ans.shape)
    # print('output_size = ',true_data.shape)
    np.savetxt('./output/output.csv', ans, delimiter=',')

    for i in range(0, num_files):
        mean_error1[i] = abs((ans[i, 0] - datay[i])) / datay[i]
    error_sum = np.sum(mean_error1)
    mean_error = error_sum / (len(mean_error1))
    print("与真值误差为：", mean_error1)

    for i in range(0, num_files):
        mean_error2[i] = abs((ans[i, 0] - predict[i])) / predict[i]
    error_sum = np.sum(mean_error2)
    mean_error = error_sum / (len(mean_error2))
    print("与预测值误差为：", mean_error2)

    rknn.release()
