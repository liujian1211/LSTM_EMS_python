import os
import numpy as np
from rknn.api import RKNN
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 设置rknn模型和测试数据文件夹的路径
ONNX_MODEL = './model/lstm_model.onnx'
QUANT_DATA = './dataset.txt'
RKNN_MODEL = './model/lstm.rknn'

DATA_PATH = './data/test'
TRUE_PATH = './data/true/true.npy'

input_expand = 1            # 与输入保持一致，扩展一个维度
input_high = 1              # 由于测试数据为一维，所以将数据的另一个维度设置为1
input_width = 2           # 输入数据的维度

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/raw_data.xlsx", sheet_name="#18-2",engine='openpyxl', nrows=100)
num_files = data_df.shape[0]

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']
target_column = 'Qdc'

dataX = data_df[selected_features].values
datay = data_df[[target_column]].values

# 归一化数据
scaler = MinMaxScaler()
data_normalized1 = scaler.fit_transform(dataX)
data_normalized2 = scaler.fit_transform(datay)

# 划分特征和目标变量
true_data = datay  # 目标变量

# 导入推理测试数据
input_data = data_normalized1.reshape((num_files, input_expand, input_high, input_width))
input_data = input_data.astype(np.float32)
np.savetxt('./output/input.csv', input_data.reshape((num_files, input_width)), delimiter=',')
print('true_data = ',input_data.shape)
np.savetxt('./output/output.csv', true_data, delimiter=',')
print('output_size = ',true_data.shape)

# 初始化变量
ans = np.zeros((num_files, input_expand), dtype=np.float32)   # 创建推理结果张量
mean_error = np.arange(num_files*input_expand, dtype=np.float32)   # 创建推理结果张量

if __name__ == '__main__':

    # Create RKNN object
    rknn = RKNN()

    # pre-process config
    print('--> config model')

    rknn.config(target_platform='rk3568')
    print('done')

    # Load model
    print('--> Loading model')
    ret = rknn.load_onnx(
        model=ONNX_MODEL,
        input_size_list=[[input_expand, input_high, input_width]])
    if ret != 0:
        print('Load model failed!')
        exit(ret)
    print('done')

    # Build model
    print('--> Building model')
    ret = rknn.build(
        do_quantization=True, 
        dataset=QUANT_DATA)
    if ret != 0:
        print('Build model failed!')
        exit(ret)
    print('done')

    # Init runtime environment
    print('--> Init runtime environment')
    ret = rknn.init_runtime(
        target=None,
        device_id=None
    )
    
    if ret != 0:
        print('Init runtime environment failed!')
        exit(ret)
    print('done')
    
    # Export rknn model
    print('--> Export rknn model')
    ret = rknn.export_rknn(RKNN_MODEL)
    if ret != 0:
        print('Export rknn model failed!')
        exit(ret)
    print('done')

    # # 量化精度分析
    # rknn.accuracy_analysis(
    #     inputs = [input_data[0]],
    #     output_dir = "./output", # 表示精度分析的输出目录
    #     target=None,
    #     device_id=None
    # )

    # Inference
    print('--> Running model')
    for i in range(0, num_files):
        outputs = rknn.inference(inputs=[input_data[i]])
        ans[i] =  np.array(outputs)
    ans = scaler.inverse_transform(ans)
    np.savetxt('./output/output.csv', ans, delimiter=',')

    for i in range(0, num_files):
        mean_error[i] = abs((ans[i] - datay[i])) / datay[i]

    has_inf = np.isinf(mean_error)
    if np.any(has_inf):
        print("存在无穷大的元素，剔除计算剩余元素")# 使用布尔索引选择非无穷大的元素
        valid_error = mean_error[~has_inf]

        # 计算剩余元素的和
        error_sum = np.sum(valid_error)
        mean_error = error_sum / (len(valid_error))
    else:
        error_sum = np.sum(mean_error)
        mean_error = error_sum / (len(mean_error))

    print("平均误差为：", mean_error)

    rknn.release()
