import numpy as np
import pandas as pd
import onnx
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler

# 从 Excel 文件中读取数据
data_df = pd.read_excel(r"./data/raw_data.xlsx", sheet_name="#18-2")

# 选择需要的特征列和目标列
selected_features = ['辐照度', '环境温度']
target_column = 'Qdc'
# data = data_df[selected_features + [target_column]].values
dataX = data_df[selected_features].values
datay = data_df[[target_column]].values
# time_data = pd.to_datetime(data_df[["Year", "Month", "Day", "Hour"]])  # 时间列（合并）
time_data = pd.to_datetime(data_df['日期'].astype(str) + ' ' + data_df['时间'].astype(str))
# print(type(time_data))
# print(time_data)
data_time = time_data.values
data_time = data_time.astype(str)

# 归一化数据
scaler = MinMaxScaler()
data_normalized1 = scaler.fit_transform(dataX)
data_normalized2 = scaler.fit_transform(datay)

# 划分特征和目标变量
X = data_normalized1[:, :]  # 特征
y = data_normalized2[:, -1]  # 目标变量
# 组合特征与时间
X = np.concatenate((X, data_time.reshape(-1, 1)), axis=1)


# 划分训练集和测试集
X_test_ini = X
y_test = y

X_test = X_test_ini[:, :2]
X_test = X_test.astype(np.float64)
X_test_time = X_test_ini[:, 2]
# print(X_test_time)
torch.manual_seed(42)  # 保证每次跑的结果相同
# 转换为 PyTorch 张量

X_test = torch.tensor(X_test, dtype=torch.float32)
X_test = X_test.unsqueeze(1)

y_test = torch.tensor(y_test, dtype=torch.float32)
# print(X_test)

# 加入注意力机制
class AttentionLSTM(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, dropout=0.0):
        super(AttentionLSTM, self).__init__()

        self.hidden_size = hidden_size
        self.num_layers = num_layers

        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout)
        self.attention = nn.Linear(hidden_size, 1)  # 注意力权重计算
        self.fc = nn.Linear(hidden_size, output_size)


    def forward(self, x):
        batch_size, seq_len, _ = x.size()
        h_0 = torch.zeros(self.num_layers, batch_size, self.hidden_size)
        c_0 = torch.zeros(self.num_layers, batch_size, self.hidden_size)

        out, _ = self.lstm(x, (h_0, c_0))
        attention_scores = self.attention(out).squeeze(2)
        attention_weights = torch.softmax(attention_scores, dim=1)
        attention_out = torch.bmm(attention_weights.unsqueeze(1), out).squeeze(1)

        final_output = self.fc(attention_out)
        return final_output

    def save(self, path):
        # 保存模型参数
        torch.save(self.state_dict(), path)

# 初始化模型
input_size = len(selected_features)  # 输入特征数
hidden_size = 128  # 隐藏层256，单独lstm128
num_layers = 3  # LSTM层8，单独lstm10
output_size = 1
dropout = 0.0  # dropout层，防止过拟合
mlp_hidden_size = 256
bidirectional = False  # 是否使用双向LSTM

# 加载模型
loaded_model = AttentionLSTM(input_size, hidden_size, num_layers, output_size)

# 加载 ONNX 模型
model = onnx.load("./model/lstm_v0.onnx")

# 将 ONNX 模型转换为 PyTorch 模型
torch_model = torch.onnx.export(model, "./model/lstm_v0.pth", X_test)
loaded_model.load_state_dict(torch.load('./model/lstm_v0.onnx'))

# 在测试集上进行预测
y_pred1 = loaded_model(X_test)
tensor_with_grad = torch.tensor(y_pred1, requires_grad=True)
y_pred = tensor_with_grad.detach().clone()
y_pred = y_pred.squeeze(dim=0)

# 反归一化预测结果
y_pred_unscaled = scaler.inverse_transform(y_pred.numpy())
print(type(y_pred_unscaled))
print('预测值：', y_pred_unscaled)

# 反归一化真实值
y_test_unscaled = scaler.inverse_transform(y_test.numpy().reshape(-1, 1))
print('测试值：', y_test_unscaled)

# 计算相对误差
relative_error = np.abs(y_pred_unscaled - y_test_unscaled) / np.abs(y_test_unscaled)
mean_relative_error = np.mean(relative_error)
print("平均相对误差%：", mean_relative_error * 100)
